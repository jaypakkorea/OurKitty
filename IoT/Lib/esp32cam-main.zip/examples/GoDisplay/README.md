# GoDisplay: camera image display for ODROID-GO

This example runs on [ODROID-GO](https://wiki.odroid.com/odroid_go/odroid_go) game console.
It displays images captured by ESP32-CAM and retrieved over HTTP.
